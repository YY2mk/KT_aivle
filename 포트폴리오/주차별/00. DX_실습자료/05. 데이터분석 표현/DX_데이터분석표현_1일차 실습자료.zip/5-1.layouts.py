import streamlit as st

st.title('Unit 5. Layouts & Containers')
st.caption('참조사이트: https://docs.streamlit.io/library/api-reference/layout')

# sidebar- with 사용하기 📧  📱  ☎︎
with 


add_selectbox =



if add_selectbox == 





# columns  
# 고양이 https://images.pexels.com/photos/2071873/pexels-photo-2071873.jpeg?auto=compress&cs=tinysrgb
# 개     https://images.pexels.com/photos/3361739/pexels-photo-3361739.jpeg?auto=compress&cs=tinysrgb
# 부엉이 https://images.pexels.com/photos/3737300/pexels-photo-3737300.jpeg?auto=compress&cs=tinysrgb

st.header('2. Columns')


with 

    
 


    
# tabs - width=200

st.header('3. Tabs')


with





    
# 파일실행: File > New > Terminal(anaconda prompt) → python -m streamlit run streamlit\5-1.layouts.py